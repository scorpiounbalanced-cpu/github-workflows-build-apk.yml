# Vampire Diaries Engine — Standalone Mode

What’s new:
- **Bundled campaign** (`assets/campaign_bundled.json`) so the app runs out-of-the-box.
- **Persona pack** in `assets/` + router config.
- **Offline AI fallback** (RuleSynth) when no endpoint/key is set.
- **Online AI** remains available (OpenAI-compatible endpoint).

How to build (no PC? use GitHub Actions from your phone):
1) Upload this project to a GitHub repo.
2) Add a workflow that runs `./gradlew assembleDebug` and uploads `app/build/outputs/apk/debug/app-debug.apk`.

How to use:
- In-app **AI Settings**: leave URL/Key empty for offline RuleSynth; fill them to use your provider.
- Import your campaign.json from storage, or edit `assets/campaign_bundled.json` and rebuild.

Generated 2025-10-14T20:55:24.219369Z
