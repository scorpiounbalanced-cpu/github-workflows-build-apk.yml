package com.vampire.diaries.engine.ui
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.vampire.diaries.engine.core.*
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader

@Composable
fun AppRoot() {
  val nav = rememberNavController()
  MaterialTheme(colorScheme = darkColorScheme(
    primary = Color(0xFFB50F2B), background = Color(0xFF0D070A), onBackground = Color(0xFFF5EAEE),
    surface = Color(0xFF161015), onSurface = Color(0xFFF5EAEE)
  )) {
    NavHost(navController = nav, startDestination = "home") {
      composable("home") { HomeScreen(nav) }
      composable("settings") { SettingsScreen(nav) }
      composable("engine") { EngineScreen(nav) }
    }
  }
}

@Composable fun HomeScreen(nav: NavHostController) {
  val ctx = LocalContext.current
  var notice by remember { mutableStateOf<String?>(null) }
  var loaded by remember { mutableStateOf(loadCampaign(ctx)) }
  val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
    if (uri != null) {
      val txt = readTextFromUri(ctx, uri)
      try {
        val json = Json { ignoreUnknownKeys = true }
        loaded = json.decodeFromString(Campaign.serializer(), txt)
        saveCampaign(ctx, loaded)
        notice = "Imported: ${loaded.title}"
      } catch (e: Exception) { notice = "Parse error: ${e.message}" }
    }
  }
  Scaffold(topBar = { SmallTopAppBar(title = { Text("Vampire Diaries Engine") },
    actions = { TextButton(onClick = { nav.navigate("settings") }) { Text("AI Settings") } }) },
    floatingActionButton = { ExtendedFloatingActionButton(onClick = { nav.navigate("engine") }, text = { Text("Run Engine") }) }
  ) { pad ->
    Column(Modifier.padding(pad).padding(16.dp)) {
      Text("Load or continue your campaign.", fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(8.dp))
      Button(onClick = { launcher.launch(arrayOf("application/json")) }) { Text("Import campaign.json") }
      Spacer(Modifier.height(12.dp))
      Text("Current: ${loaded.title}")
      Spacer(Modifier.height(8.dp)); notice?.let { Text(it, color = Color(0xFFE6BAC4)) }
    }
  }
}
fun readTextFromUri(ctx: Context, uri: Uri): String {
  ctx.contentResolver.openInputStream(uri).use { i -> BufferedReader(InputStreamReader(i)).use { br -> return br.readText() } }
}

@Composable fun SettingsScreen(nav: NavHostController) {
  val ctx = LocalContext.current
  var url by remember { mutableStateOf(loadPref(ctx,"ai_url") ?: "") }
  var key by remember { mutableStateOf(loadPref(ctx,"ai_key") ?: "") }
  var model by remember { mutableStateOf(loadPref(ctx,"ai_model") ?: "gpt-4o-mini") }
  var temp by remember { mutableStateOf(loadPref(ctx,"ai_temp") ?: "0.4") }
  var maxT by remember { mutableStateOf(loadPref(ctx,"ai_max") ?: "320") }
  val mode = if (url.isBlank() || key.isBlank()) "Offline (RuleSynth)" else "Online (Provider)"

  Scaffold(topBar = { SmallTopAppBar(title = { Text("AI Settings — $mode") }) }) { pad ->
    Column(Modifier.padding(pad).padding(16.dp)) {
      OutlinedTextField(value = url, onValueChange = { url = it }, label = { Text("Endpoint URL (optional)") }, modifier = Modifier.fillMaxWidth())
      OutlinedTextField(value = key, onValueChange = { key = it }, label = { Text("API Key (optional)") }, modifier = Modifier.fillMaxWidth())
      OutlinedTextField(value = model, onValueChange = { model = it }, label = { Text("Model") }, modifier = Modifier.fillMaxWidth())
      Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(value = temp, onValueChange = { temp = it }, label = { Text("Temperature") }, modifier = Modifier.weight(1f))
        OutlinedTextField(value = maxT, onValueChange = { maxT = it }, label = { Text("Max tokens") }, modifier = Modifier.weight(1f))
      }
      Spacer(Modifier.height(12.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
          savePref(ctx,"ai_url",url); savePref(ctx,"ai_key",key); savePref(ctx,"ai_model",model); savePref(ctx,"ai_temp",temp); savePref(ctx,"ai_max",maxT)
        }) { Text("Save") }
        OutlinedButton(onClick = { nav.popBackStack() }) { Text("Back") }
      }
      Spacer(Modifier.height(8.dp))
      Text("Leave URL & Key empty to run fully offline with the built-in RuleSynth.", color = Color(0xFFE6BAC4))
    }
  }
}

@Composable fun EngineScreen(nav: NavHostController) {
  val ctx = LocalContext.current
  var campaign by remember { mutableStateOf(loadCampaign(ctx)) }
  var epIndex by remember { mutableStateOf(0) }
  var scIndex by remember { mutableStateOf(0) }
  var aiInput by remember { mutableStateOf("Give atmospheric narration for this scene; do not change canon beats.") }
  var aiOut by remember { mutableStateOf("") }
  var useKatherine by remember { mutableStateOf(true) }
  val online = !loadPref(ctx,"ai_url").isNullOrBlank() && !loadPref(ctx,"ai_key").isNullOrBlank()

  Scaffold(topBar = {
    SmallTopAppBar(title = { Text(campaign.title) }, navigationIcon = { TextButton(onClick = { nav.popBackStack() }) { Text("Back") } },
      actions = { AssistChip(label = { Text(if (online) "AI: Online" else "AI: Offline") }, onClick = {}) })
  }) { pad ->
    val ep = campaign.episodes.getOrNull(epIndex); val sc = ep?.scenes?.getOrNull(scIndex)
    Column(Modifier.padding(pad).padding(12.dp)) {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { epIndex = (epIndex-1).coerceAtLeast(0); scIndex=0 }) { Text("◀ Episode") }
        Button(onClick = { epIndex = (epIndex+1).coerceAtMost(campaign.episodes.size-1); scIndex=0 }) { Text("Episode ▶") }
      }
      Spacer(Modifier.height(8.dp)); Text("Episode: ${ep?.id} — ${ep?.title}", fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { scIndex = (scIndex-1).coerceAtLeast(0) }) { Text("◀ Scene") }
        Button(onClick = { scIndex = (scIndex+1).coerceAtMost((ep?.scenes?.size?:1)-1) }) { Text("Scene ▶") }
      }
      Spacer(Modifier.height(8.dp)); Text("Scene: ${sc?.id} — ${sc?.name} (${sc?.type})")
      Spacer(Modifier.height(8.dp))
      LazyColumn(modifier = Modifier.weight(1f, fill = true)) {
        items(sc?.beats ?: emptyList()) { b -> BeatRow(b) }
        item {
          if (sc?.type == SceneType.Branch && !sc.choices.isNullOrEmpty()) {
            Spacer(Modifier.height(8.dp)); Text("Choices:", fontWeight = FontWeight.Bold)
            sc.choices!!.forEach { ch ->
              OutlinedButton(onClick = {
                val tgt = ch.outcome.substringAfter("REJOIN").trim().ifEmpty { ch.outcome }
                scIndex = ep?.scenes?.indexOfFirst { it.id == tgt }?.takeIf { it >= 0 } ?: scIndex
              }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Text("${ch.key}: ${ch.label} → ${ch.outcome}") }
            }
          }
        }
      }
      Divider(); Spacer(Modifier.height(8.dp))
      Text("Ask AI (${if (online) "online provider" else "offline RuleSynth"})", fontWeight = FontWeight.Bold)
      OutlinedTextField(value = aiInput, onValueChange = { aiInput = it }, modifier = Modifier.fillMaxWidth())
      Row {
        Checkbox(checked = useKatherine, onCheckedChange = { useKatherine = it }); Text("Katherine persona flavor")
        Spacer(Modifier.weight(1f)); Button(onClick = {
          aiOut = "Thinking..."; callAI(ctx, campaign, epIndex, scIndex, aiInput, useKatherine) { aiOut = it }
        }) { Text("Ask AI") }
      }
      Text(aiOut)
    }
  }
}
@Composable fun BeatRow(b: Beat) {
  Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
    Text(b.type.name, style = MaterialTheme.typography.labelSmall, color = Color(0xFFF19AA8))
    if ((b.speaker ?: "").isNotBlank()) Text("${b.speaker}:", fontWeight = FontWeight.SemiBold, color = Color(0xFFFFD1D9))
    if ((b.text ?: "").isNotBlank()) Text(b.text!!)
  }
}
