package com.vampire.diaries.engine.core
import android.content.Context
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
@Serializable data class Campaign(val title:String="Vampire Diaries Campaign", val flags:Flags=Flags(), val episodes:List<Episode>=emptyList())
@Serializable data class Flags(val CanonLock:Boolean=true, val DialogueCanonLock:Boolean=true)
@Serializable data class Episode(val id:String, val title:String, val scenes:List<Scene>)
@Serializable data class Scene(val id:String, val name:String, val type:SceneType, val beats:List<Beat>=emptyList(), val next:String?=null, val choices:List<Choice>?=null)
@Serializable data class Beat(val type:SceneBeatType, val speaker:String?=null, val text:String?=null)
@Serializable data class Choice(val key:String, val label:String, val outcome:String)
enum class SceneType { Fixed, Branch, Rejoin }
enum class SceneBeatType { CANON_LINE, STAGE_DIR }
fun saveCampaign(ctx:Context, c:Campaign){ val t=Json.encodeToString(Campaign.serializer(),c); ctx.getSharedPreferences("vampire",0).edit().putString("campaign",t).apply() }
fun loadCampaign(ctx:Context):Campaign{ val t=ctx.getSharedPreferences("vampire",0).getString("campaign",null)
  return if(t!=null) Json.decodeFromString(Campaign.serializer(),t) else Campaign(
    episodes=listOf(
      Episode("S01E01","Pilot", scenes=listOf(
        Scene("S01E01_01","Cemetery Encounter",SceneType.Fixed, beats=listOf(
          Beat(SceneBeatType.STAGE_DIR,null,"Night air. Wind in the trees. A crow watches."),
          Beat(SceneBeatType.CANON_LINE,"<CHAR>","<paste canon line here>"),
          Beat(SceneBeatType.STAGE_DIR,null,"Footsteps on leaves.")
        ), next="S01E01_02"),
        Scene("S01E01_02","Hallway Tension",SceneType.Branch, beats=listOf(Beat(SceneBeatType.STAGE_DIR,null,"Bell rings; lockers slam.")),
          choices=listOf(Choice("A","Engage","REJOIN S01E01_03"), Choice("B","Avoid","REJOIN S01E01_04"))),
        Scene("S01E01_03","Aftermath",SceneType.Rejoin, beats=listOf(Beat(SceneBeatType.STAGE_DIR,null,"Hall thins.")), next="S01E01_05"),
        Scene("S01E01_04","Avoided",SceneType.Rejoin, beats=listOf(Beat(SceneBeatType.STAGE_DIR,null,"You slip away.")), next="S01E01_05"),
        Scene("S01E01_05","Classroom Setup",SceneType.Fixed, beats=listOf(Beat(SceneBeatType.STAGE_DIR,null,"Roll call.")))
      ))
    )
  )
}
fun savePref(ctx:Context,k:String,v:String){ ctx.getSharedPreferences("vampire",0).edit().putString(k,v).apply() }
fun loadPref(ctx:Context,k:String):String?= ctx.getSharedPreferences("vampire",0).getString(k,null)
