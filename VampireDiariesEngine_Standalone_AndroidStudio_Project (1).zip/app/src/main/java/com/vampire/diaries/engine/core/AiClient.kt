package com.vampire.diaries.engine.core
import android.content.Context
import android.os.Handler
import android.os.Looper
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

fun callAI(ctx: Context, campaign: Campaign, epIndex:Int, scIndex:Int, prompt:String, useKatherine:Boolean, cb:(String)->Unit){
  val url = loadPref(ctx,"ai_url")
  val key = loadPref(ctx,"ai_key")
  if (url.isNullOrBlank() || key.isNullOrBlank()) {
    // Local fallback
    cb(ruleSynth(campaign, epIndex, scIndex, prompt, useKatherine))
    return
  }
  val model = loadPref(ctx,"ai_model") ?: "gpt-4o-mini"
  val temp = (loadPref(ctx,"ai_temp") ?: "0.4").toDoubleOrNull() ?: 0.4
  val maxT = (loadPref(ctx,"ai_max") ?: "320").toIntOrNull() ?: 320
  val ep = campaign.episodes.getOrNull(epIndex)
  val sc = ep?.scenes?.getOrNull(scIndex)
  val persona = if (useKatherine)
    "You are Katherine Pierce: seductive, calculating, protective, dramatically playful. Address Tevin in second person. No copyrighted TV lines. Respect canon beats; provide atmospheric narration *around* them."
  else
    "You are a moody Narrator. Add atmospheric, non-canon embellishments around fixed beats. No copyrighted dialogue."

  val ctxJson = JSONObject().apply{
    put("episode", ep?.id); put("episode_title", ep?.title)
    put("scene", sc?.id); put("scene_name", sc?.name); put("type", sc?.type?.name)
    put("beats", JSONArray().apply{ sc?.beats?.take(30)?.forEach{ b ->
      put(JSONObject().apply{ put("type", b.type.name); put("speaker", b.speaker); put("text", b.text) })
    }})
  }

  val messages = JSONArray().apply{
    put(JSONObject().put("role","system").put("content", persona))
    put(JSONObject().put("role","user").put("content",
      "Context:\n$ctxJson\nTask: $prompt\nRules:\n- No copyrighted quotes.\n- Do not contradict fixed beats.\n- <= 220 words."))
  }
  val body = JSONObject().apply{ put("model", model); put("temperature", temp); put("max_tokens", maxT); put("messages", messages) }
  val client = OkHttpClient()
  val req = Request.Builder().url(url).addHeader("Authorization","Bearer $key").addHeader("Content-Type","application/json")
    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
  Thread{
    try{
      client.newCall(req).execute().use{ resp ->
        val text = resp.body?.string()?:""
        if(!resp.isSuccessful){
          post(cb, "AI error ${resp.code}: $text")
        } else {
          val obj = JSONObject(text)
          val content = obj.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?:"(no content)"
          post(cb, content)
        }
      }
    }catch(e:Exception){ post(cb, "AI request failed: ${e.message}") }
  }.start()
}

private fun post(cb:(String)->Unit, msg:String){ Handler(Looper.getMainLooper()).post{ cb(msg) } }

// Extremely small, rules-based local generator: stitches mood words + beat hints.
private val moods = listOf("the air tastes like thunder","shadows lean in","footsteps hesitate","the room forgets to breathe","a choice sharpens like fangs")
private fun ruleSynth(c:Campaign, ei:Int, si:Int, prompt:String, kat:Boolean):String{
  val ep = c.episodes.getOrNull(ei); val sc = ep?.scenes?.getOrNull(si)
  val beatHints = sc?.beats?.take(3)?.mapNotNull{ it.text }?.joinToString(" • ") ?: ""
  val spice = moods.random()
  return if (kat) {
    "You want heat, Tevin? Keep your eyes on me. $spice. We don't touch the canon—yet—but we dance around it. ${if(beatHints.isNotBlank()) "Hints: $beatHints. " else ""}Do you push, or do you let them chase? Choose, and I’ll make it worth the trouble."
  } else {
    "The scene holds its breath: $spice. ${if(beatHints.isNotBlank()) "Beats to honor: $beatHints. " else ""}You can press forward or fold back to safety. Either way, the night keeps score."
  }
}
